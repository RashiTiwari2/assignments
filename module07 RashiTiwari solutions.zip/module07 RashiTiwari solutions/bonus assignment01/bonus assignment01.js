
let intlist=[]
let mylist=[]
let N=parseInt(prompt())
for(let i=0; i<N; i++){
    random1=Math.floor(Math.random() * 201) - 100;
    intlist.push(random1)
    
}
console.log(`${intlist}`)
for(let i=0; i<intlist.length; i++){
    if(intlist[i]>intlist[i+1]){
     
     mylist.push(intlist[i])
    }
}

console.log(`${mylist}`)
