
let books=prompt("list of books")
books=books.split(",")


if(books.includes('Pinocchio') || books.includes('The Little Prince')){

  console.log(`Your items to buy:
  A special gift — set of stickers \n`+(books.join('\r\n'))                               
  )
    
}
else{
  console.log(`Your items to buy: \n`
  +(books.join('\r\n'))
  )
}
