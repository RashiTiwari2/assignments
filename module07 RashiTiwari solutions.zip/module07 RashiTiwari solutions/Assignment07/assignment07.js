const guests = [
        ["001", "Johnson", "Table 2"],
        ["002", "Nisha", "Table 10"],
        ["003", "Vasav", "Table 1"],
        ["004", "Uddin", "Table 7"]
     ];
let input;

while(input !== 0 || guests.length !== 0) {
    input = prompt("Enter id or surname:");
    if (input === "0" || guests.length===0) {
        break;
    }
    let found = false;
    for (let i = 0; i < guests.length; i++) {
        if (guests[i][0] === input || guests[i][1] === input) {
            console.log(`Welcome to ${guests[i][2]}`);                 
            guests.splice(i, 1);
            found = true;
            break;
        }
    }
    if (!found) {
        console.log("Sorry, there is no such reservation.");
    }
}