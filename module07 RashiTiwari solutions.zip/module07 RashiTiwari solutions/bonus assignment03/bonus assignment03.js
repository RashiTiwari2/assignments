let numbers = [];
for (let i = 0; i < 10; i++) {
  numbers.push(Math.floor(Math.random() * 200) - 100);
}
console.log("Generated set: " + numbers);
numbers.sort((a, b) => b - a);
console.log("Sorted in descending order set : " + numbers);