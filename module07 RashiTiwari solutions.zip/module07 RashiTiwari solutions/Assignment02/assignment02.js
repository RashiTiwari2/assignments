let prices=parseInt(prompt());
let sum=0

while(prices!==0){

sum=(sum+prices);

                                                    //   solOUI___-2
prices=parseInt(prompt())
}

if(sum>20000){
let dp=sum-(sum*(30/100))    //discountprice
dp=Math.round(dp/ 100) * 100;
console.log(`The total sum to pay (with the activated discount) is ${dp}`)
}
else{console.log(sum)}