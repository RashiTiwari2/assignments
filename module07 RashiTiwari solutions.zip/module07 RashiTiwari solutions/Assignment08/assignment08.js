let participants = prompt("Enter participants separated by commas: ");
let arr = participants.split(",");
console.log("Participants: " + arr);


let usedNumbers = [];

for (let i = 0; i < arr.length; i++) {
    let randomNumber;
    do {
       
        randomNumber = Math.floor(Math.random() * 10) + 1;
    } while (usedNumbers.indexOf(randomNumber) !== -1); 
   
    usedNumbers.push(randomNumber); 

    console.log(arr[i] + " - " + randomNumber);
}

//let participants=Joshi, Mohammad, Ta, Vati, Manna, Miya, Tivari
