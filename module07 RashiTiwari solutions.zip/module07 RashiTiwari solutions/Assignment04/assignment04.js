let str = "The Batman, Don't Look Up, Against the Ice, Sing 2, Love Hard"
movieList = str.split(",");
let age = parseInt(prompt("Enter age"))
console.log(`Why wouldn’t you watch these movies:`)
if(age<18){
    let moviesunder18 = Array.from(movieList);
    if(moviesunder18.includes("The Batman")){                                                      
        moviesunder18.splice(moviesunder18.indexOf("The Batman"), 1, "Coco")
    }
    if(moviesunder18.includes("Against the Ice")){
        moviesunder18.splice(moviesunder18.indexOf("Against the Ice"), 1, "Free Guy")
}
console.log(moviesunder18.join(","))
} else{
    console.log(movieList.join(","))
}

