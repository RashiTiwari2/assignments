
//sol6
let goods = [
  ["Apples", "fruit"],
  ["Milk 3.2%", "dairy products"],
  ["Potato", "vegetables"],
  ["Brinjal", "vegetables"],
  ["Mango", "fruit"],
  ["Cheese", "dairy products"]
]

let cat = []
for (let each of goods) {
  if (!cat.includes(each[1])) {
    cat.push(each[1])
  }
}

console.log(cat)
for (let each of cat) {
  console.log(each.toUpperCase())
  for (let eachGood of goods) {
    if (each == eachGood[1]) {
      console.log(eachGood[0])
    }
  }
}

