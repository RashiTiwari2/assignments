const participants = [
    "John M.", "David H.", "Rajesh A.",
    "Sunita S.", "Mohammed A.", "Ram J.",
    "Anita R.", "Suresh R.", "Sara M.",
    "Nick C.", "Lakshmi N."]
    let team1 =[]
    let team2 = []                                                                
    for(let each of participants){
        let num = Math.floor(Math.random()*2)
        if(num ==1){
            team1.push(each)
        } else {
            team2.push(each)
        }
    }
while(Math.abs(team1.length - team2.length) >1){
    if(team1.length >team2.length){
        team2.push(team1.pop())
    } else{
        team1.push(team2.pop());
    }
}
console.log(`Team 1 :${team1}`)
console.log(`Team 2 :${team2}`)

