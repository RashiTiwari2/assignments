let countries=[]
let counter=0

while(true){

  country=prompt("name of countries")
    if(country==0){
    break;
  }
  countries.push(country)
  counter++
 countries.sort()
  
}
console.log(`Wow! There are coins from ${counter} countries in this collection:`)
 console.log(countries.join('\r\n'))
