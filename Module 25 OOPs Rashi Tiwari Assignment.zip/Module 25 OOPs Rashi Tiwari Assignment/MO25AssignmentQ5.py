from abc import ABC, abstractmethod


class Bank(ABC):
    def bank_info(self):
        print("welcome to bank")

    @abstractmethod
    def interest(self):
        pass


class SBI(Bank):
    def interest(self):
        print(" In SBI bank 4 rupees interest")


class Axis(Bank):
    def interest(self):
        print(" In Axis bank 7 rupees interest")


sbi = SBI()
sbi.bank_info()
sbi.interest()

axis = Axis()
axis.bank_info()
axis.interest()
