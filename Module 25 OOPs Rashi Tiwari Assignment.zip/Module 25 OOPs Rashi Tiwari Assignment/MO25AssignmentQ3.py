class Vehicle:
    def __init__(self, name, color, price):
        self.name = name
        self.color = color
        self.price = price

    def max_speed(self):
        print("Vehicle max speed is 150 ")

    def gear(self):
        print("Vehicle have 6 gear")

    def show(self):
        print("Details :", self.name, self.color, self.price)


class Car(Vehicle):
    def __init__(self, name, color, price):
        super(). __init__(name, color, price)

    def max_speed(self):
        print("Car max speed is 100 ")

    def gear(self):
        print("Car have 4 gear")


class Bus(Vehicle):
    def __init__(self, name, color, price):
        super(). __init__(name, color, price)

    def max_speed(self):
        print("Bus max speed is 200 ")

    def gear(self):
        print("Bus have 8 gear")


vehicle = Vehicle("ABC", "black", 100)
vehicle.show()
print("---------")

car = Car("BMW", "red", 20000)
car.show()
car.max_speed()
car.gear()
print("---------")

bus = Bus("Tavera x1", "black", 150000)
bus.show()
bus.max_speed()
bus.gear()
