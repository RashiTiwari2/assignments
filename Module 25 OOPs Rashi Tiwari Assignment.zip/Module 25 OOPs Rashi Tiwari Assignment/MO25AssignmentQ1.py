class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f" Person name:  {self.name}")
        print(f" Person city:  {self.age}")


class Student(Person):
    def __init__(self, name, age, section):
        super().__init__(name, age)
        self.section = section

    def displayStudent(self):
        print(f" Person name:  {self.name}")
        print(f" Person age:  {self.age}")
        print(f" Person Section:  {self.section}")


student = Student("john Mark", 18, "Science")
student.display()
print("-------")
student.displayStudent()
