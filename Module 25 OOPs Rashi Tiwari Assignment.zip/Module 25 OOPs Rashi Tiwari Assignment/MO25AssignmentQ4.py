class Calculate:
    def add(self, *args):
        if not args:
            return 0
        if len(args) > 3:
            return "to many arguments"
        return sum(args)


calculate = Calculate()
print("sum Value", calculate.add())
print("sum Value", calculate.add(2, 4))
print("sum Value", calculate.add(1, 2, 5, 6, 7))
