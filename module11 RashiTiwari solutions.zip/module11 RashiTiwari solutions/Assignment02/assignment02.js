
function findSecondLargestNumber(array){
(array.sort((a,b)=>b-a))
console.log(array[1])
}
let output=prompt().split(",")
let myoutput= output.map(val => parseInt(val))

findSecondLargestNumber(myoutput)

