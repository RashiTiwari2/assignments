
function printMarks(...arrray){
let [first,second]=arrray
return [first,second]
}

output={name: 'David', id: 1, marks:[89, 76, 45, 83, 93]} 
console.log(printMarks(...output.marks))

