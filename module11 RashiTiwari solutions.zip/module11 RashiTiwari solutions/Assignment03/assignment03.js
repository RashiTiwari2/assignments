
function joinAarray(obj1,obj2){
    obj1 = [{name: "David", id: 1},{name: "Jon", id: 2}]

    obj2 = [{name: "Ram", id: 4},{name: "Mohan", id: 3}]
    console.log(myobj=[...obj1,...obj2])

}
joinAarray()
