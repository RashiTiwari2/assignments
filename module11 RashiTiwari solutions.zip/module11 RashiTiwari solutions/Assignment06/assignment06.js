let student = {
  marks: [23, 56, 78, 89, 43],
  num: 78,
  SwapExists(num) {
    let Swap = parseInt(num.toString().split('').reverse().join(''));
    console.log(Swap)
    if (student.marks.includes(Swap)) {
      return `true [because ${Swap} exists in array]`;
    } else {
      return  `false [because ${Swap}  doesn't exist in array]`;
    }
  }
};

console.log(student.SwapExists(student.num));












// let marks = prompt("Enter the marks array separated by comma").split(',').map(Number);
// let num = parseInt(prompt("Enter the number"));

// let student = {
//   marks: marks,
//   num: num,
//   largestSwapExistsInMarks: function(num) {
//     let largestSwap = parseInt(num.toString().split('').reverse().join(''));
//     return this.marks.includes(largestSwap);
//   }
// };

// console.log(student.largestSwapExistsInMarks(student.num));