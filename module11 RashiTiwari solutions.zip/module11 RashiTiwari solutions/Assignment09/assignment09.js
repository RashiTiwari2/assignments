function find2NumberSum(arr, target) {

  for (let i = 0; i < arr.length; i++) {
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[i] + arr[j] == target) {
        return [arr[i], arr[j]];
      }
    }
  }

}
console.log(find2NumberSum([7, -5, 2, 0, 1, 14, 4], -5))

