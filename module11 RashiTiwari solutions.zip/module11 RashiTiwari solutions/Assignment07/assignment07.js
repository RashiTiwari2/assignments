function flip(...arr){
    let res=[]
    for(let i=0; i<arr.length; i++){
res.push([1,0][arr[i]])
    }
    console.log(res)
}
flip(0, 1, 1, 1, 0, 0, 1)
