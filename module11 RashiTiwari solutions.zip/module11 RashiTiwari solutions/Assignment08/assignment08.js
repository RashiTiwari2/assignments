function findMostExpensiveCar(cars) {
  let maxPrice = 0;
  let ExpensiveCar;

  for (let car in cars) {
    if (cars[car] > maxPrice) {
      maxPrice = cars[car];
      ExpensiveCar = car;
    }
  }

  return `The most expensive car is ${ExpensiveCar}`;
}

let cars = { 'hyundai': 35000, 'tesla': 100000, 'MG': 80000 };
console.log(findMostExpensiveCar(cars));

