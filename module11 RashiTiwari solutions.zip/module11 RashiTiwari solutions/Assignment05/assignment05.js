function totalPrice(arr1, arr2) {

    let order = [];
    let maxmoney = Math.max(...arr2);
    let i = arr2.indexOf(maxmoney)
    order.push({ [arr1[i]]: maxmoney })
    return { order }
}

let items = ["item1", "item2", "item3"]
let values = [200, 400, 260]


console.log(totalPrice(items, values));
