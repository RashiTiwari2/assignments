let index = 0, newArr = []; //1,2,3,....
function findduplicate(array){
  for(let i=0; i<array.length-1; i++ ){
   
      if(newArr.includes(array[i])){
   return `the duplicate is ${array[i]} , and it’s position in the list is ${i+1} with index of ${i}.`                      
      }
      newArr.push(array[i])

    
  }
}
 let x=(prompt("enter"))
 let output=[];
 stringarray=x.split(",")
 console.log(stringarray)
 for(i=0; i<stringarray.length; i++){
    output.push(parseInt(stringarray[i]))
 }

 console.log(findduplicate(output))


