

function checkIfDivisible(y){
    num1 = parseInt(y.split(",")[0])
    console.log(num1)
    num2 = parseInt(y.split(",")[1])
    console.log(num2)
    if(num1%num2===0){
        return 'completely-divisible!';
    }return 'not-divisible!';                                   //SOL~~`4
}
let output=checkIfDivisible(prompt("Enter two numbers"))
console.log(output)






