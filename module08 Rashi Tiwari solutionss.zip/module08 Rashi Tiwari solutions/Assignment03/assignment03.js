
function findmin(y) {

    num1 = parseInt(y.split(",")[0])
    num2 = parseInt(y.split(",")[1])


    if (num1 > num2) {
        return num2;
    }
    else {
        return num1
    }
}
console.log(findmin(prompt("i/p")))

