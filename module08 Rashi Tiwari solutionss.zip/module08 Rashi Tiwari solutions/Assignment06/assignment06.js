function pow(a , b)
{
    if (b == 0)
        return 1;
         
    var answer = a;
    var increment = a;
    var i, j;
     
    for (i = 1; i < b; i++)
    {
        for (j = 1; j < a; j++)
        {
            answer += increment;
                                                   
           
        }
        increment = answer;
    }
     
    return answer;
}
 
 
let a=parseInt(prompt("Enter num1"))
let b=parseInt(prompt("Enter num2"))
console.log(pow(a,b))

