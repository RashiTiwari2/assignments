function findVolume(r){
    let V=(4/3)*3.14*(r**3)
    return V;                              
}
let output=findVolume(parseInt(prompt("Ener the radius")))
console.log(output)
