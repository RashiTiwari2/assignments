
newArr=[]
let positon; 
function fidNum(X){

    let stringarray=X.split(",")
 let array=[];
 for (let i = 0; i < stringarray.length; i++) {
    array.push(parseInt(stringarray[i]));
}


  for(i=0; i<array.length; i++){
  if(array[i+1] -array[i]   > 1){
    newArr.push(array[i]+1)
   positon= newArr.push(i+2)

    return newArr;
  }

}
}

let output=(fidNum(prompt("Enter")))
console.log(output)

