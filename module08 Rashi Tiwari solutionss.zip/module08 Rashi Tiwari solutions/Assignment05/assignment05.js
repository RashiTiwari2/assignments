function threeLargest(X) {
    let stringarray = (X.split(","))
    let arr = [];
    for (let i = 0; i < stringarray.length; i++) {
        arr.push(parseInt(stringarray[i]));
    }

    console.log(arr+"  -Input")
    let first = arr[0]
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] > first) {
            first = arr[i]
        }
    }

    let second = arr[0]
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] > second && arr[i] < first) {
            second = arr[i]
        }
    }

    let third = arr[0]
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] > third && arr[i] < second) {
            third = arr[i]
        }
    }
    return [first, second, third]
    
}
output = prompt("i/p")
console.log(threeLargest(output))





