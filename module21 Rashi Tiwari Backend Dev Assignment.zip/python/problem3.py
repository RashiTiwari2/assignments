fullname = "John Doe"
email = "john.doe@gmail.com"
age = 30
address = "NYC"
isFresher = True
salary = 45893.40

print(int(salary))
