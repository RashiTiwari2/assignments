fullname="John Doe"
email="john.doe@gmail.com"
age=30
address="NYC"
isFresher=True



print(type(fullname))
print(type(email))
print(type(age))
print(type(address))
print(type(isFresher))