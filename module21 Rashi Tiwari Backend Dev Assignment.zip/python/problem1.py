fullname="John Doe"
email="john.doe@gmail.com"
age=30
address="NYC"
isFresher=True