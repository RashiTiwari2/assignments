Input = [10.5, 45.67, 32.3, 9.28, 7.3, 55.67, 123.4, 11.2, 6.25, 3.9]
largest_num = Input[0]

for item in Input:
    if item > largest_num:
        largest_num = item

print(largest_num)
