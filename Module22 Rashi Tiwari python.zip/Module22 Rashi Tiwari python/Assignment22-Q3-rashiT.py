def Calculate_payment(play_duration, subscribers):
    payment = 10
    if play_duration > 1000 and subscribers > 1000000:
        payment += 40
    elif play_duration > 500 and subscribers > 500000:
        payment += 30
    elif play_duration > 100 and subscribers > 100000:
        payment += 20

    return payment


print(Calculate_payment(120, 5400567))
