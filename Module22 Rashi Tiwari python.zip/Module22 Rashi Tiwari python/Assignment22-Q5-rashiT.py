def find_big_channels(BigChannels):
    mychannel = []
    for channel in BigChannels:
        if len(channel) > 15 and channel not in mychannel:
            mychannel.append(channel)

    return mychannel


BigC = ["Indie Folk Central", "RoadTravelledLess",
        "Netflix", "PlayStation", "RoadTravelledLess", "Python is Awesome", "JavaScript"]

print(find_big_channels(BigC))
