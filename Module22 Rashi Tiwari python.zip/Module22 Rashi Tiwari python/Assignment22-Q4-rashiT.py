channels = ["Indie Folk", "RoadTravelled",
            "MusicStation", "Python", "JavaScript"]
output = []
for channel in channels:

    if "music" in channel.lower() or "folk" in channel.lower() or "song" in channel.lower():
        output.append(channel)

print(output)
