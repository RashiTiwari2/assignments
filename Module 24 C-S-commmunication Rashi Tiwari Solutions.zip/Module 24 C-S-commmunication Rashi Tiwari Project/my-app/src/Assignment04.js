import React, { useState } from 'react'


function Assignment04() {
    const [id, setId] = useState();
    const [title, setTitle] = useState();
    const [body, setBody] = useState();

    const handleSubmit = (e) => {
        e.preventDefault();
        const newPost = { title, body, id }
        fetch("https://jsonplaceholder.typicode.com/todos", {
            method: 'PUT',
            headers: { 'content-type': 'application/json' },

            body: JSON.stringify(newPost)

        })
            .then(res => res.json())
            .then(data => {
                console.log(data)
                alert("Your data posted succesfully")
            });

    }

    return (
        <>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor='postid'>id</label>
                    <input id='id' type='text' value={id} onChange={(e) => setId(e.target.value)} />
                </div>
                <div>
                    <label htmlFor='title'>Title</label>
                    <input id='title' type='text' value={title} onChange={(e) => setTitle(e.target.value)} />
                </div>
                <div>
                    <label htmlFor='body'>body</label>
                    <input id='body' type='text' value={body} onChange={(e) => setBody(e.target.value)} />
                </div>

                <button type="submit">Update Post</button>
            </form>
        </>
    )
}

export default Assignment04


