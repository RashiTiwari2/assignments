let array= [2, 1, 2, 2, 2, 3, 4, 2];
let move=2
function moveToEnd(array,move){
    let start=0;
    let end =array.length-1
    while(start< end){

        while(start<end && array[end]==move){
            end--;
        }
        if(array[start]==move){
         let temp=array[start]
         array[start]=array[end]
         array[end]=temp
        }
        start++
    }
    return array
}
console.log(moveToEnd(array, move))



// function moveElements(array, move) {
//     for (let i = array.length - 1; i >= 0; i--) {
//       if (array[i] === move) {
//         array.splice(i, 1);
//         array.push(move);
//         console.log(array)
//       }
//     }
//     return array;
//   }
  
//   let array = [2, 1, 2, 2, 2, 3, 4, 2];
//   let move = 2;
//   console.log(moveElements(array, move));
  
  