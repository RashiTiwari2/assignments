let Competitions = [
    ["HTML", "C#"],
    ["C#", "Python"],
    ["Python", "HTML"],
]
let result = [0, 0, 1]
function findWwinner(comp, res) {
    let teams = {}
    for (let i = 0; i < comp.length; i++) {

        if (res[i] == 0) {
            // console.log(res[i])
            console.log(comp[i][1])
            teams[comp[i][1]] = teams[comp[i][1]] + 3 || 3;
        }
        else {
            console.log(comp[i][0])
            teams[comp[i][0]] = teams[comp[i][0]] + 3 || 3;
        }
    }
    console.log(teams)
    let max = 0;
    let winnerTeam = ''
    for (let each of Object.keys(teams)) {
        if (teams[each] > max) {
            max = teams[each]
            winnerTeam = each
        }
    }
    console.log(winnerTeam + " -Winner")

}
(findWwinner(Competitions, result))