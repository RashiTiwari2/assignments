let myarray=[5,1,22,6,-1,8,10]
let mysequence=[1,6,-1,10]
function isSubSequence(array, sequence){
    let index=0
    for(let i=0; i<array.length; i++){
        if(index===sequence.length){
            break;
        }
        if(array[i]===sequence[index] && index < sequence.length){
            index++
        }
    }
    return index===sequence.length
}
console.log(isSubSequence(myarray, mysequence))