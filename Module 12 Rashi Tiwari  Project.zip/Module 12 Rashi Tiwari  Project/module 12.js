
function change_text(){
    let date = document.getElementById("date").value;
    let month = document.getElementById("month").value;
    let year = document.getElementById("year").value;

   //  console.log(date)
   //  console.log(month)
   //  console.log(year)

    let monthlist=[31,28,31,30,31,30,31,31,30,31,30,31]
    
    let isInputValidated=validateFormValue(date,month,year)
    if(isInputValidated){
       let result= document.getElementById("msg")


        let currentdate = new Date().getDate();
        let currentMonth = new Date().getMonth()+1;
        let currentYear = new Date().getFullYear();
        console.log(currentMonth+"-currentmonth")
        console.log(currentdate+"-currentdate")
        console.log(currentYear+"-currentyear")

        if(date > currentdate){
            currentdate=currentdate+ monthlist[month-1]
            currentMonth=currentMonth-1
            
        }
        if(month > currentMonth){
            currentMonth = currentMonth + 12
            currentYear=currentYear-1
            
        }
        let noOfDays=currentdate-date
        let noOfMonths = currentMonth-month
        let noOfYears = currentYear - year

      //   console.log(noOfDays)
      //   console.log(noOfMonths)
      //   console.log(noOfYears)
      
        result.innerText=`${noOfYears} years, ${noOfMonths} months and ${noOfDays} days`
    }
    
}
    function validateFormValue(date,month,year){
    let monthlist=[31,28,31,30,31,30,31,31,30,31,30,31]


    if(date == "" ){
      let result= document.getElementById("msg")
       result.innerText="Please provide Date"
       return false;  
    }
    if(month == ""){
      let result= document.getElementById("msg")
        result.innerText="Please provide month"
        return false;
     }
     if(year == ""){
      let result= document.getElementById("msg")
        result.innerText="Please fill year input."
        return false
     }

     if(parseInt(date) <=0){
      let result= document.getElementById("msg")
       result.innerText= "Date cannot be 0 or less than 0"
        return false;
     }
     if(parseInt(month) <=0){
        let result= document.getElementById("msg")
        result.innerText="Month cannot be 0 or less than 0"
        return false;
     }
     if(parseInt(year) <=0){
      let result= document.getElementById("msg")
      result.innerText="Year cannot be 0 or less than 0"
        return false;
     }



      if(month > 12){
        let result= document.getElementById("msg")
        result.innerText="Please provide Month value in the range from 1 to 12"
        return false;
    }

      if(String(year).length < 4){
    
   let result= document.getElementById("msg")
        result.innerText="Provide year in format YYYY"
        return false
     }
     if(parseInt(date)>monthlist[parseInt(month)-1]){
      let result= document.getElementById("msg")
      result.innerText="Please provide valid Date with respect to Month"
        return false;
     }

     if(isNaN(date)){
      let result= document.getElementById("msg")
      result.innerText="Please provide valid Date"
        return false;
     }
     if(isNaN(month)){
        let result= document.getElementById("msg")
        result.innerText="Please provide valid month"
        return false;
     }
     if(isNaN(year)){
      let result= document.getElementById("msg")
      result.innerText="Please provide valid year"
        return false;
     }

    
     return true
   
    
 };


