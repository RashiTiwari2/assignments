class Employee:
    def __init__(self, name, salary, dept):
        self.name = name
        self.__salary = salary
        self.dept = dept

    def get_salary(self):
        return self.__salary

    def show(self):
        print(
            f"Name:  {self.name} Salary: {self.get_salary()} Dept: {self.dept}")


employee1 = Employee("Steve Rogers", 10000, "IT")
employee1.show()
employee1.name = "Tony"
employee1.show()
print(employee1.__salary)
