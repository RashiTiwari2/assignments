class Book:
    def __init__(self, title, author, price):
        self.title = title
        self.author = author
        self.price = price

    def view(self):
        print(self.title, self.author, self.price)
        print(
            f"Book Title: -> {self.title} Book Author: -> {self.author} Book Price: -> {self.price} $")


myBook = Book("Python Complete Reference", "Tony stark", "28")
myBook.view()
