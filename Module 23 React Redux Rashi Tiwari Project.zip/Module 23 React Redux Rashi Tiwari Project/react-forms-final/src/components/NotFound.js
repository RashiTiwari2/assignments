import React from 'react'

const NotFound = () => {
  return (
    <p className='not-found-message'>Page you're looking for doesn't exist</p>
  )
}

export default NotFound