function checkNum(arr, func) {
    for (let each of arr) {
        console.log(`${each} is an ${func(each)} number`)
    }
}
let arr = [2, 4, 6, 5, 8, 7, 1, 9, 39, 22, 13, 40, 55]

function isNumberEven(num) {
    if (num % 2 == 0) {
        return "even"
    } else {
        return "odd"
    }
}
checkNum(arr, isNumberEven)