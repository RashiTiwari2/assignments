let array = [1, 2, 3, 4, 5];
function emptyArray(arr) {
    while (arr.length !== 0) {
        arr.pop();
    }
    console.log(arr);
}


emptyArray(array);