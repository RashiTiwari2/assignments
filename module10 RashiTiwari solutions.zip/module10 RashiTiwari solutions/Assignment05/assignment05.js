let arr=[1, 2, 3, 4, 5, 6, 7, 8, 9];
function calculateSum(sum,item){
   return sum+=item
}
let newcalu=arr.reduce(calculateSum,0) 
console.log(newcalu)