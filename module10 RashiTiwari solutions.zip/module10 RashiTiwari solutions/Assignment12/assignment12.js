const friendsArray = [
    { id: 1, name: "Abhay", amount: 2000 },

    { id: 2, name: "Bunty", amount: 3000 },

    { id: 3, name: "Chinki", amount: 5900 },

    { id: 4, name: "Dimple", amount: 1000 },

    { id: 5, name: "Erica", amount: 2370 }

];

let sum = friendsArray.reduce((acc, eachobj) => acc + eachobj.amount, 0)
console.log(sum)

let ascending = friendsArray.slice().sort((x, y) => x.amount - y.amount)
console.log(ascending)

let descending = friendsArray.slice().sort((x, y) => y.amount - x.amount)
console.log(descending)


console.log(descending[0])
console.log(descending[descending.length - 1])


