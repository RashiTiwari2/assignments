let listArr = ['spiderman', 'superman', 'wonder women', 'ironman', 'black widow',
    'batman', 'thor']
function superhero(arr) {

    for (let i = 0; i < arr.length; i++) {

        console.log(` ${arr[i]} is present at ${i} and has a length of ${arr[i].length}`)
    }
}
(superhero(listArr))


