let arr = [1, 2, 3, 4, 5]
let updateArr = (arr, func) => {
  console.log("the older array is:")
  console.log(arr)
  func(arr)
}

let printModified = (arr) => {
  arr.push(6)
  console.log("the modified array is:")
  console.log(arr)
}
updateArr(arr, printModified)










