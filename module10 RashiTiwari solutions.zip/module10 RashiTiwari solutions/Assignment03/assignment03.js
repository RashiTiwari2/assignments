let manufacturers = ['audi', 'BMw', 'ForD', 'mG', 'tata', 'MAHINDRA'];

function uniformvalues (manufacturers)  {
    return {
        allLowerCase: manufacturers.map(manufacturer => manufacturer.toLowerCase()),
        allUpperCase: manufacturers.map(manufacturer => manufacturer.toUpperCase())
    }
}

console.log(uniformvalues(manufacturers));