let mainfunc=function(par){
   par()
};
let secondfunction=function(){
    console.log("Hello Coders")
};
mainfunc(secondfunction)