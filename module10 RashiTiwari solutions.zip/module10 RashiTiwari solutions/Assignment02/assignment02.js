let addNum = function (par1, par2) {
   return par1 + par2;
}
let secondf = function () {
   return 10;
};
console.log(addNum(15, secondf()))
