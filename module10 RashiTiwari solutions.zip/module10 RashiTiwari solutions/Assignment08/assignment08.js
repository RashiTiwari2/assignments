let array= [1, 2, 3, 4, 5];
let newArr=array.map(duplicateArr);
function duplicateArr(item){
     return array.push(item)
}
console.log(array)

