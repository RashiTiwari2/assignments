let arr=[2, 3, 5, 4, 8, 6, 9];
let newArr=arr.map(knowSquare);
function knowSquare(item){
    return item**2
}
console.log(newArr)
