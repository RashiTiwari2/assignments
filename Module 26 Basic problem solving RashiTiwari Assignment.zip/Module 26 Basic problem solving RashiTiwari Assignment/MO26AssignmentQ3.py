def findNum():
    inputNum = int(input("num: "))
    if inputNum < 7:
        return "Down"
    elif inputNum == 7:
        return "equal"
    else:
        return "Up"


noOfCases = int(input("number of cases: "))
for i in range(noOfCases):
    print("output: ", findNum())
