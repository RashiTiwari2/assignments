def addNum():
    sum = 0
    inputNum = input("Num: ")
    for each in inputNum:
        num = int(each)
        sum += num
    return sum


noOfCases = int(input("number of cases: "))
for i in range(noOfCases):
    print("output: ", addNum())
