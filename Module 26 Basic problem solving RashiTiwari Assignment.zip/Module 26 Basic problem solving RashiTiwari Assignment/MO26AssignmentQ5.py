def is_sum_product_num(number):
    product = 1
    sum = 0
    for val in number:
        sum += int(val)
        product *= int(val)
    return sum*product == int(number)


noOfCases = int(input("number of cases: "))
for val in range(noOfCases):
    data = input("Enter the number: ")
    if is_sum_product_num(data):
        print("yes")
    else:
        print("no")
