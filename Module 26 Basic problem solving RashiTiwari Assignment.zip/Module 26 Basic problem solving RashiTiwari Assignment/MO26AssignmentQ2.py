def findAverage():
    inputCases = input("weights of students: ").split()

    sum = 0
    for each in inputCases:
        num = int(each)
        sum += num
        Average = sum/10
    return Average


noOfCases = int(input("number of cases: "))
for i in range(noOfCases):
    print("output: ", findAverage())
