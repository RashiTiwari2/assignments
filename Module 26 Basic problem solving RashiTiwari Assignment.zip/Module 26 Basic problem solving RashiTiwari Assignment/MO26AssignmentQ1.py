def findPrime():
    inputArray = input("Add numbers: ").split()
    arr = []
    for each in inputArray:
        if len(each) % 2 == 0:
            arr.append(each)
    myArray = " ".join(arr)
    return myArray


noOfCases = int(input("number of cases: "))
for i in range(noOfCases):
    print("output: ", findPrime())
