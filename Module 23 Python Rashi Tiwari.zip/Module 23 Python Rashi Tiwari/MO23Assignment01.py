t1 = (1, 2)
t2 = (3, 4)

combined_tuple = t1+t2
print(combined_tuple)
