
videoTuple = ('Tuple in Python', [13.0, 134.5, 89.3, 98.4])
print(max(videoTuple[1]))


# videoTuple = ('Tuple in Python', [13.0, 134.5, 89.3, 98.4])
# highest = 0
# for val in videoTuple[1]:
#     if highest < val:
#         highest = val
# print(highest)
