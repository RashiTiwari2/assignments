
videoTuple = ('Tuple in Python', [13.0, 134.5, 89.3, 98.4])
dict = {}
for i in range(0, len(videoTuple), 2):
    dict = {videoTuple[i]: videoTuple[i+1]}
print(dict)


# videoTuple = ('Tuple in Python', [13.0, 134.5, 89.3, 98.4])
# output = {videoTuple[0]: videoTuple[1]}
# print(output)
