video = ["List in Python", [34.5, 19.2, 381.3, 56.2, 16.1]]
video[1].sort()
print(video[1])
video[1].sort(reverse=True)
print(video[1])
