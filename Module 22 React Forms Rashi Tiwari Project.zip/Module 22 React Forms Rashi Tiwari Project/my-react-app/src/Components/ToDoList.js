import React from 'react'
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ToDoForm from './ToDoForm';
import Select from 'react-select'
import Tags from './Tags.json';

let status=[
    {
      "name":"All",
      "id":1
    },
    {
      "name":"Completed",
      "id":2
    }
  ]
let sort=[
    {
      "name":"Asc",
      "id":1
    },
    {
      "name":"Desc",
      "id":2
    }
  ]
function ToDoList(props) {
  
    const [tasks, setTasks] = useState([]);
    

    let navigate = useNavigate();
    
    function handleSubmit(e) {
        e.preventDefault()
        const newTask = e.target.elements[0].value;
        setTasks([...tasks, newTask]);
        e.target.reset();
    }
    function createdetailedtask(event) {
        event.preventDefault()
        navigate("/ToDoForm", true)
    }

    return (
        
        <div className='todo-form'>

            {/* <h2>ToDo</h2> */}
            <form onSubmit={handleSubmit} className="to-do-list-form">
                <div className='create-task-div'>
                <input className='create-task-input' type="text" />
                <button className='create-task-btn' type='submit' >Create Task</button>
                </div>
                <button onClick={createdetailedtask} className='create-detail-task-btn'>Create detailed task</button>
                <h2>Tasks</h2>
                <div className='filters'>
                    <div className='filters-div'></div>
                   <p> Filters:</p>
                    <label>by status</label>
                    <Select className='filter-input'
                   options ={status.map(stat => ({ value: stat.name, label: stat.name, ...stat }))} 
                       />
                   
                    <label>by tags</label>
                    <Select className='filter-input'
                    isMulti
                   options ={Tags.map(tag => ({ value: tag.name, label: tag.name, ...tag }))} 
                       />
                    {/* <input className='filter-input'></input> */}
                    <label>sort by</label>
                    <Select className='filter-input'
                   options ={sort.map(order => ({ value: order.name, label: order.name, ...order }))} 
                       />
                </div>
                <hr></hr>
                {tasks.map((task, index) => (
                    <div key={index}>
                        <p>{task}</p>
                    </div>
                ))}
               
            </form>
        </div>
      
    )
}
export default ToDoList