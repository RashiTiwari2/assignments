import React from 'react'
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useState } from 'react';
import Datepicker from "react-datepicker" // import DatePicker from "react-datepicker"
import "react-datepicker/dist/react-datepicker.css";
import * as Yup from 'yup';
import { FcAddImage } from 'react-icons/fc';
import Tags from './Tags.json';

const createTaskSchema = Yup.object().shape({
  task: Yup.string().required('Task is required')
  .min(4, 'task must be at least of 4 characters'),
  deadline: Yup.string()
    .required('deadline is required'),
  description: Yup.string().required('description is required')
    .min(10, 'description must be at least of 10 characters'),
  isPriority: Yup.string().required(),
  tags: Yup.string().required('tag is required'),
});

const ToDoForm = () => {
  const [initialFormValues] = useState({
    task: "",
    deadline: new Date(),
    description: "",
    isPriority: false,
    tags: '',
    image: ""
  })


  const tagOptions = Tags.map(tag => ({
    label: tag.name,
    value: tag.id
  }));

  function handleSubmit(values) {
    console.log(values);
  }
  function cancelOnClick() {
    window.location.reload();
  }
  function handlePriority(setFieldValue, event) {
    setFieldValue("isPriority", event.target.checked);
  }


  return (
    <>
      <h2 className='detailed-task-header'>Create Task</h2>
      <div className='detailed-task-div' >
        <div className='detailed-task-box'>
          <Formik initialValues={initialFormValues} validationSchema={createTaskSchema} onSubmit={handleSubmit}>
            {(props) => (
              <Form>
                <label className='detailed-task-label' htmlFor="task" >
                  Task
                  <Field className='detailed-task-input' id="task" type="text" name="task" />
                  <ErrorMessage name="task" component="div" className="error-message" />
                </label>
                <label className='detailed-task-label' htmlFor='deadline'>
                  Deadline
                  <Datepicker
                    id="deadline" name="deadline"
                    selected={props.values.deadline}
                    onChange={(date) => props.setFieldValue("deadline", date)}
                    showTimeSelect
                    dateFormat="Pp"
                    todayButton="Today"

                    className="detailed-task-input"
                  />
                  <ErrorMessage name="deadline" component="div" className="error-message" />
                </label>
                <label className='detailed-task-label' htmlFor='description'>
                  Description
                  <Field className='detailed-task-input' type='textarea' id='description' name="description" />
                  <ErrorMessage name="description" component="div" className="error-message" />
                </label>
                <div className='detailed-task-checkbox'>
                  <label  htmlFor='priority'>
                    <Field id='priority' type="checkbox"
                      name="isPriority"
                      onChange={(event) => handlePriority(props.setFieldValue, event)}
                      checked={props.values.isPriority} />
                    priority
                    <ErrorMessage name="priority" component="div" className="error-message" />
                  </label>
                </div>

                <label className='detailed-task-label' htmlFor='tags'>
                  Tags
                  <Field className='detailed-task-input' as="select" id='tags' name="tags">
                    <option value="">Select a tag...</option>
                    {tagOptions.map(option => (
                      <option key={option.value} value={option.value}>{option.label}</option>
                    ))}
                  </Field>
                  <ErrorMessage name="tags" component="div" className="error-message" />
                </label>

                <label className='detailed-task-label' htmlFor='image'>
                  <FcAddImage fontSize={50} />
                  <input 
          type="file"  name="image"  id="image"  style={{ display: "none" }}/> 
            </label>

                <div className='detailed-task-btnbox'>
                  <button className='create-task-btn' type='submit'>Create</button>
                  <button className='create-task-btn2' onClick={cancelOnClick} type='button' >Cancel</button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </>
  )
}

export default ToDoForm