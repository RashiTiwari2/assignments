import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom';

const Home = () => {

    let navigate = useNavigate();
    function logout(){
        navigate("/Login", true);
    }
    
     let location = useLocation();
    console.log(location.pathname)

    function handleSubmit(e) {
        e.preventDefault()
    }
   
    return (
        <>
            <div><h3>Welcome! Login Successful</h3></div>
            <div className='todo-form'>
                <h2>To-do-list </h2>
                <form onSubmit={handleSubmit} className="to-do-list-form">
                    <input type="text" />
                    <button >Add Task</button>
                    <button onClick={logout} className='login-btn' type="submit">Logout</button>
                </form>
            </div>
        </>
    )

}

export default Home