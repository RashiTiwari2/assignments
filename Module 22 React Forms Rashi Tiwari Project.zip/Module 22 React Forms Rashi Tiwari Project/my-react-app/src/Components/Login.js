import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import LoginDetails from './LoginDetails.json';

const loginSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string()
    .required('Password is required')
    .min(6, 'Password must be at least 6 characters')
    .max(12, 'Password can be no more than 12 characters'),
});

function Login() {
  const location = useLocation();
  const navigate = useNavigate();
  console.log(location.pathname);

  const initialValues = {
    email: '',
    password: '',
  };

  function handleSubmit(values) {
    if (LoginDetails.email === values.email && LoginDetails.password === values.password) {
      navigate('/ToDoList', true);
    } else {
      navigate('/invalid', true);
    }
  }

  return (
    <div className="login-form">
      <h3 className="login-form-h3">Login-Page</h3>
      <Formik initialValues={initialValues} validationSchema={loginSchema} onSubmit={handleSubmit}>
        {({ values,  }) => (
          <Form>
            <label htmlFor="email">
              Email
              <Field className="login-form-input" type="email" name="email" id="email" value={values.email}   />
              <ErrorMessage name="email" component="div" className="error-message" />
            </label>
            <label htmlFor="password">
              Password
              <Field className="login-form-input" type="password" name="password" id="password" value={values.password}   />
              <ErrorMessage name="password" component="div" className="error-message" />
            </label>
            <button className="login-btn" type="submit" >
              Login
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default Login;
