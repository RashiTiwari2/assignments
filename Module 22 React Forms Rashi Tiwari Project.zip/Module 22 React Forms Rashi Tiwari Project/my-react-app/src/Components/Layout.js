import React from 'react'
import { useNavigate } from 'react-router-dom';

const Layout = () => {

  let navigate = useNavigate();
  // function logOut(){
  //     navigate("/Login", true);
  // }
  return (
    <div >
    {/* <button onClick={logOut} className='logout-btn' type="submit">Logout</button> */}

      <p className='app-heading'>ToDo</p>
      </div>
  )
}

export default Layout