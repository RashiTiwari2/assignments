import logo from './logo.svg';
import './App.css';
import Login from './Login';
import ToDoList from './ToDoList';
import { useState } from 'react';

function App() {

  const [LoginState, setLoginState]= useState(false)
  return (
    <>
    { !LoginState && <Login updateState={setLoginState}/>}
    {LoginState && <ToDoList/>}
    </>
  );
}

export default App;
