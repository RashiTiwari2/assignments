import React from 'react'

function ToDoList(){

    function handleSubmit(e){
           e.preventDefault()
    }

    return(
        <div>
             <h2>To-do-list Component</h2>
             <form onSubmit={handleSubmit} className="to-do-list-form">
        <input type="text" />
        <button >Add Task</button>
        <button>Create Detailed Task</button>
        <h3>Tasks</h3>
        </form>
        </div>
    )
}

export default ToDoList