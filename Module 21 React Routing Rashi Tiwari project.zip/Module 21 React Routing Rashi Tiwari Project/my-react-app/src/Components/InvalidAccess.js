import React from 'react'
import { useNavigate } from 'react-router';
const InvalidAccess = () => {
    let navigate = useNavigate();

    function redirectLogin(){
        navigate("/Login", true);
    }
  return (
    <>
    <div>Invalid Credentials</div>
    <button onClick={redirectLogin} className='login-btn' type="submit">Back to login page</button>
    </>
  )
}

export default InvalidAccess