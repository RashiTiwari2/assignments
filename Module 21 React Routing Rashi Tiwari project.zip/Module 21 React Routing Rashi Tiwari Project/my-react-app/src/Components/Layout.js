import React from 'react'

const Layout = () => {
  return (
    <div ><p className='app-heading'>ToDo App</p></div>
  )
}

export default Layout