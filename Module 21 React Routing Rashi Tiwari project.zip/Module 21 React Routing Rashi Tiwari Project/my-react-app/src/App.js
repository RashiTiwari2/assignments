import logo from './logo.svg';
import './App.css';
import Login from './Components/Login';
import ToDoList from './Components/ToDoList';
import { useState } from 'react';
import {Routes, Route, BrowserRouter} from 'react-router-dom'
import NotFound from './Components/NotFound';
import InvalidAccess from './Components/InvalidAccess';
import Home from './Components/Home';
import Layout from './Components/Layout';


function App() {

  const [LoginState, setLoginState]= useState(false)
 
  return (
    <>
    <div className='main-container'>
    <BrowserRouter>
    <Layout></Layout>
    <Routes>
      <Route path='/' element={<Home />}/>
      <Route path='/Login' element={<Login />}/>
      <Route path='/ToDoList' element={<ToDoList />}/>
      <Route path='/invalid' element={<InvalidAccess/>}/>
      <Route path='/*' element={<NotFound/>}/>
    </Routes>
    </BrowserRouter>
    </div>
    </>
    
  );
}

export default App;
