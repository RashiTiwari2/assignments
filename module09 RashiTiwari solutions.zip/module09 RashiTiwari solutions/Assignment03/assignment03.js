
let str = prompt("")
let strArr = str.split(",")
let person = {
    name: strArr[0],
    age: strArr[1],
    roomno: strArr[2],
    greet: function () {
        return `I am ${this.name} ,aged ${this.age}, living in room ${this.roomno}`
    }
}
console.log(person.greet())

