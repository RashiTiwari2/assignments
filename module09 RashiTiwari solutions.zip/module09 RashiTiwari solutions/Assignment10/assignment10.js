function submitdata() {
    let person = {
        Firstname: simpleform.firstname.value,
        Lastname: simpleform.lastname.value,
        Email: simpleform.email.value,
        City: simpleform.city.value,
        Gender: simpleform.gender.value
    }

    console.log(`This is ${person.Firstname} ${person.Lastname}, ${person.Gender} from ${person.City}  and my email id is ${person.Email} `)
}
