let person = {
    name: "vishal",
    class: "x",
    seatNo: 987,
}
let keys = Object.keys(person)
console.log(keys)
