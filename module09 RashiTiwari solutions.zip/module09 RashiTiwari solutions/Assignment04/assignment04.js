
let object = [
    {
        firstname: "John",
        lastname: "Apple",
        age: 27,
        joinedDate: "December 15,2017"
    },
    {
        firstname: "Ana",
        lastname: "Rosy",
        age: 25,
        joinedDate: "January 15,2019"
    },
    {
        firstname: "Zion",
        lastname: "Albert",
        age: 30,
        joinedDate: "February 15,2011"
    }
]
object.sort((a, b) => a.firstname.localeCompare(b.firstname))
for (let obj of object) {


    console.log(`This is ${obj.firstname} ${obj.lastname}, aged ${obj.age} joined the company on ${obj.joinedDate} `)
}