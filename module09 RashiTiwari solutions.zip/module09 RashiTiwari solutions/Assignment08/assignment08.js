
let person = [
    {
        name: "John",
        city: "Delhi"
    },
    {
        name: "Tony",
        city: "Mumbai"
    },
    {
        name: "Steve",
        city: "Bangalore"
    }
]
for (let each of person) {
    each.onelineintro = function () {
        return `This is ${this.name} from ${this.city}`
    }

    console.log(each.onelineintro())
}