let array = [];
let numofProducts = parseInt(prompt("Enter the number of products"))
for (let i = 0; i < numofProducts; i++) {
    let name = prompt("Enter the name of product")
    let quantity = parseInt(prompt("Enter the quantity of products"))
    let object = {
        name: name,
        quantity: quantity
    }
    array.push(object)
}
for (let each of array) {
    console.log(`${each.name}:${each.quantity} `)
}

