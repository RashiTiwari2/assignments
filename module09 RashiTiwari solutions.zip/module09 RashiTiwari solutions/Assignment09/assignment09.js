
let employees = [
    {
        firstName: 'Steve',
        lastName: 'Rogers',
        age: 27,
        joinedDate: 'December 15, 2017'
    },
    {
        firstName: 'Tony',
        lastName: 'Stark',
        age: 25,
        joinedDate: 'January 15, 2019'
    },
    {
        firstName: 'Bruce',
        lastName: 'Banner',
        age: 30,
        joinedDate: 'February 15, 2011'
    }
]

let employees01 = {
    firstName: "Black",
    lastName: "Widow",
    age: 27,
    joinedDate: "December 25, 2018"
}
employees.push(employees01)


let employees02 = {
    firstName: "Winter",
    lastName: "Soldier",
    age: 27,
    joinedDate: "October 15, 2007"
}
employees.unshift(employees02)

console.log(`output1:`)
for (let each of employees) {
    console.log(` This is ${each.firstName} ${each.lastName}, aged ${each.age} joined the company on ${each.joinedDate}`)
}

let employeesNew = Object.seal(employees);
for (let eachh of employeesNew) {
    eachh.joinedDate = " December 13, 2021."
}
console.log("output2:")
for (let eachh of employeesNew) {
    console.log(` This is ${eachh.firstName} ${eachh.lastName}, aged ${eachh.age} joined the company on ${eachh.joinedDate}`)
}

