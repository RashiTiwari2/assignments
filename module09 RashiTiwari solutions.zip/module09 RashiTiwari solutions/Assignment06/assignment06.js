function formcircle(radiusC) {
    let circle = {
        radiusC,
        calculateperimeter: (2 * 3.14 * radiusC),
        calculatearea: (3.14 * radiusC ** 2)
    }
    return `Perimeter of circle is ${circle.calculateperimeter}\r\n Area of circle is ${circle.calculatearea}`
}
function formsquare(radiusS) {
    let square = {
        radiusS,
        calculateperimeter: (4 * radiusS),
        calculatearea: (radiusS ** 2)
    }
    return `Perimeter of square is ${square.calculateperimeter}\r\n Area of square is ${square.calculatearea}`
}
let shape = parseInt(prompt("Enter 1 or 2, 1 for circle and 2 for square"))
switch (shape) {
    case 1:
        console.log(formcircle(parseInt(prompt("radius of circle"))))
        break;
    case 2:
        console.log(formsquare(parseInt(prompt("radius of sq"))))
        break;
    default:
        console.log("not-valid")
}

