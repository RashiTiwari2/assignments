let cartItems = {
    shampoo: {
        quantity: 5,
        price: 278
    },
    butter: {
        quantity: 4,
        price: 80

    },
    oil: {
        quantity: 2,
        price: 142
    },


}
let sum = 0;
for (let each in cartItems) {
    sum += cartItems[each].quantity * cartItems[each].price
}
console.log("Total cart value is " + sum)