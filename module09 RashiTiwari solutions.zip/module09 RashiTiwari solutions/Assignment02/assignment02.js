let object=[
    {
        author:"bill gates",
        title:"The Road Ahead",
        readingstatus:true
    },
    {
        author:"steve jobs",
        title:"Walter Isaacon",
        readingstatus:true
    },
    {                                                                 
        author:"suzanne collins",
        title:"Mockingjay: The final book Of The Hunger Games",
        readingstatus:false
    }
]
for(let eachobj of object){
    if(eachobj.readingstatus==true){
        console.log(`I already read  ${eachobj.title} by ${eachobj.author.toUpperCase()}.`)
    }
    else{
        console.log(`I need to read  ${eachobj.title} by ${eachobj.author.toUpperCase()}.`)
    }
}
